void init_prologue(sf_prologue *heap_prologue);
void init_epilogue(sf_epilogue *heap_epilogue);
void init_first_block(sf_free_list_node *current_list, size_t available_size);